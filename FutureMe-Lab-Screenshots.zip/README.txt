FutureMe Lab screenshots
Captured from the current application build on 24 October 2026.
All grade, age, questionnaire and mission responses are demonstration data.
Numbered files show primary views and actions. quiz-01 through quiz-10 cover every question page. Files ending -full preserve the entire questionnaire page.
Source: https://github.com/dpjegankumar/futurelab
